const today = new Date();
const dateElement=document.getElementById('post-date');
dateElement.textContent = today.toDateString();

