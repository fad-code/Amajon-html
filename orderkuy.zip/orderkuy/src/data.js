const data = [
  { name: 'Pizza', desc: 'pepperoni, mushroom, mozzarella', price: 14, image: '/images/pizza.png' },
  { name: 'Hamburger', desc: 'beef, cheese, lettuce', price: 12, image: '/images/burger.png' },
  { name: 'Beer', desc: 'grain, hops, yeast, water', price: 12, image: '/images/beer.png' },
  { name: 'Hotdog', desc: 'saussage, mustard, pickles', price: 12, image: '/images/hotdog.jpg' },
];
export default data;